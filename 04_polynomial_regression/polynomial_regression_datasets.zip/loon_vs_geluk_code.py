# gecreëerd op 4/3/2022

import numpy as np
import pandas as pd

p = np.array([0.0045, 0.03, -0.5, 3, 70])
x = np.linspace(-10, 8, 1000)
y = np.polyval(p, x)

xdata = np.round(x + 15, 4)
ydata = y + np.random.randn(len(y)) * 10
ydata[ydata > 100] = 100
ydata[ydata < 0] = 0
xdata -= 4
ydata = np.round(ydata / 10, 1)

happy = pd.DataFrame(dict(jaarloon=xdata, gelukscore=ydata))
happy.to_json('loon_vs_geluk.json', orient='table', index=False)